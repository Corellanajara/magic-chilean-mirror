const generateWeather = require("./weather_current");
const generateWeatherForecast = require("./weather_forecast");

module.exports = {generateWeather, generateWeatherForecast};
